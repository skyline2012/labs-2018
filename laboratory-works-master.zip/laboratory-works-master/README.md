# laboratory-works
Algorithms for processing data in external memory
